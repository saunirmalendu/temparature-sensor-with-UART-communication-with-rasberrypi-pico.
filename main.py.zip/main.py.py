from machine import Pin
import time	
import machine, onewire, ds18x20, time
led=Pin(25,Pin.OUT)
ds_pin = machine.Pin(13)
ds_pin2=Pin(20,Pin.OUT)
ds_pin2.value(1)
time.sleep(0.5)
ds_sensor = ds18x20.DS18X20(onewire.OneWire(ds_pin))
Device = ds_sensor.scan()
print('Found DS devices1:', Device)
'''if len(Device)==0:
    ds_pin2.value(0)
    time.sleep(0.25)
    ds_pin2.value(1)
    time.sleep(0.25)
    ds_sensor = ds18x20.DS18X20(onewire.OneWire(ds_pin))
    Device = ds_sensor.scan()
    print('device is null')
    print('Found DS devices2:', Device)'''
uart = machine.UART(1)


while True:
    try:
        ds_pin2.value(1)
        led.value(1)
        time.sleep(1)
        led.value(0)
        Count=0
#         utime.sleep(0.2)
        ds_sensor.convert_temp()
        time.sleep_ms(1000)
        for sensor in Device:
            print("temp in C: ",ds_sensor.read_temp(sensor))
            uart.write(str(ds_sensor.read_temp(sensor)))
            
            #time.sleep(0.5)
    except Exception as e:
           print(str(e))
           Count=Count+1
           if Count==3:
               Count=0
               ds_pin = machine.Pin(13)
               ds_pin2.value(0)
               time.sleep(0.25)
               ds_pin2.value(1)
               time.sleep(0.25)
               ds_sensor = ds18x20.DS18X20(onewire.OneWire(ds_pin))
               #utime.sleep(0.2)
               Device = ds_sensor.scan()
               time.sleep(0.2)
               print('Found DS devices3:', Device)
               #time.sleep(2)
           